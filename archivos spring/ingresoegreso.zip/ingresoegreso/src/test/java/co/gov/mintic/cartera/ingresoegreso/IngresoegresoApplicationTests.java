package co.gov.mintic.cartera.ingresoegreso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IngresoegresoApplicationTests {

	@Test
	void contextLoads() {
	}

}
